/*
 ============================================================================
 Name		 : Party_Animals.c
 Author      : Luca Santoro 0001005415,
               Armando Spennato 0001006172,
               Riccardo Bassi 0001084538
 ============================================================================
 Description : Assignment 1 implementation.
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>
#include <sys/types.h>
#include <time.h>
#include <string.h>

#define FOREVER while(!time_up)
#define N_THREADS 19
#define GROUP_SIZE 5

/* the following values are just examples of the possible duration
  of each action and of the simulation: feel free to change them */
#define REFILL_TIME 5
#define MINGLE_TIME 12
#define END_OF_TIME 120

typedef char name_t[20];
typedef enum {FALSE, TRUE} boolean;

time_t big_bang;
boolean time_up=FALSE;

// GLOBAL VARS, TYPE DEFS ETC

// we initialize these variables to count the buddies that have to perform each action

int ready_buddies = 0; /*to count how many buddies are ready for the toast, so how many
                         buddies have filled their glass*/
int waiting= 0;       // to count how many buddies are waiting to toast
int toasting = 0;     // to count how many buddies are making the toast
int drinking = 0;     // to count how many buddies are drinking
int mingling = 0;     // to count how many buddies are mingling

// statistic

int drunk_glasses[N_THREADS] = {0};// to count the number of drunk glasses by each thread

// We declare the semaphores for the threads synchronization.

sem_t ready;   // semaphore to synchronize threads that join the group and are ready to toast.
sem_t wait;    // semaphore to synchronize threads that are waiting for the toast
sem_t toast;   // semaphore to synchronize threads that are making the toast
sem_t drink;   // semaphore to synchronize threads that wait are drinking.
sem_t mingle;  // semaphore to synchronize threads that wait are mingling.

/* we declare these semaphores below to protect the critical sections in each function and
to allow threads to access resources without concurrency.*/

sem_t mutex;
sem_t mutex1;
sem_t mutex2;
sem_t mutex3;
sem_t mutex4;

// wait_for_ready() 

/* We use the function wait_for_ready to allow threads to wait that five of
them are ready for the toast once they have filled their glasses.*/

void wait_for_ready(){

	sem_wait(&mutex); // allow only one thread at time to access the critical section and perform the following
	                  // instructions.

/* If the buddies ready for the toast are less than five we increase the number of buddies that are ready,
then we release the lock for the next thread and we wait on 'ready' semaphore for other threads.*/

	if (ready_buddies < GROUP_SIZE-1){
		ready_buddies++;  // increase the counter of buddies that are ready for toast
		sem_post(&mutex); // Unlock the mutex to exit from critical section and allow another thread to enter
		sem_wait(&ready); // wait for other threads
	}

/*When the fifth thread arrives the if condition is not respected and so we pass from if to else. So the group is completed and so
we reset to zero the variable that count the number of ready buddies and we increase the
value of 'ready' semaphore to get resources available for the next group of thread that
will arrive, then we release the mutex semaphore*/

	 else {

		ready_buddies = 0; // reset the counter of buddies that are ready for toast
		for(int i=0; i<GROUP_SIZE-1;i++){
			sem_post(&ready); // to get all resources again available
		}
		sem_post(&mutex); // Unlock the mutex to exit from critical section.
		}
}

// wait_for_toasting() 

/* We use the function wait_for_toasting() to allow thread to wait that five of them have said skol
 before they can toast. The function is implemented in the same way as before*/

void wait_for_toasting(){

	sem_wait(&mutex1);


	if (waiting < GROUP_SIZE-1){
		waiting++;           // increase the counter of buddies that are waiting for toast, so buddies that are saying skol.
		sem_post(&mutex1);   // Unlock the mutex to exit from critical section and allow another thread to enter
		sem_wait(&wait);     // wait on semaphore for other threads
	}

    else {
		waiting = 0;           // reset the counter of buddies that are waiting for toast, so buddies that are saying skol.
		for(int i=0; i<GROUP_SIZE-1;i++){
		     sem_post(&wait);  // to get all resources again available
		}  
		sem_post(&mutex1);     // Unlock the mutex to exit from critical section.
	}
}

// make_toast() 

/* we use the make_toast() function to allow thread to wait until they are making the toast.
The function is implemented in the same way as before*/

void make_toast(){

	sem_wait(&mutex2);

			if (toasting < GROUP_SIZE-1){
				toasting++;         // increase the counter of buddies that are toasting.
				sem_post(&mutex2); // Unlock the mutex to exit from critical section and allow another thread to enter
				sem_wait(&toast);  // wait on semaphore for other threads
			}

		    else {
		    	toasting = 0; // reset the counter of buddies that are toasting.
				for(int i = 0; i<GROUP_SIZE-1;i++){
						sem_post(&toast); // to get all resources again available
				 }
				sem_post(&mutex2); // Unlock the mutex to exit from critical section.
			}
	}

// wait_for_drinking() 

/* we use the function wait_for_drinking() to allow threads to wait that all five buddies
   have drunk so that they can mingle. The function is implemented in the same way
   as before*/

void wait_for_drinking(){

	sem_wait(&mutex3);

	if (drinking < GROUP_SIZE-1){
		drinking++;	  // increase the counter of buddies that are drinking.
		sem_post(&mutex3); // Unlock the mutex to exit from critical section and allow another thread to enter
		sem_wait(&drink);  // wait on semaphore for other threads
	}
    else {
		drinking = 0;  // reset the counter of buddies that are drinking.
	    for(int i=0; i<GROUP_SIZE-1;i++){
	        sem_post(&drink);  // to get all resources again available
	    }
		sem_post(&mutex3); // Unlock the mutex to exit from critical section.
	}
}

// wait_for_mingle() 

/* we use the function wait_for_mingle() to allow threads to wait that all five buddies
   have mingled so that they can go to join another group for the next toast
   The function is implemented in the same way as before*/

/* NOTE: This function is not called; we implemented it only to have the possibility that buddies
         wait that all five have mingled before to join another group */

void wait_for_mingle(){

	sem_wait(&mutex4);

	if (mingling < GROUP_SIZE-1){
		mingling++;	       // increase the counter of buddies that are mingling.
		sem_post(&mutex4); // Unlock the mutex to exit from critical section and allow another thread to enter
		sem_wait(&mingle); // wait on semaphore for other threads
		}
	else {
		mingling = 0;             // reset the counter of buddies that are mingling.
		for(int i=0; i<GROUP_SIZE-1;i++){
		      sem_post(&mingle);  // to get all resources again available
		 }
		sem_post(&mutex4);       // Unlock the mutex to exit from critical section.
		}

}

// these functions allow to color the various printf in order to distinguish them better
// in the output.

void red () {
  printf("\033[1;31m");
}

void pink () {
  printf("\033[1;95m");
}

// To make the color of the print GREEN
void green () {
 printf("\033[0;32m");
}

// To make the color of the print CYAN
void cyan () {
 printf("\033[0;36m");
}

// To make the color of the print YELLOW
void yellow () {
 printf("\033[0;33m");
}

void blue() {
 printf("\033[0;94m");
}

// To reset the color of the print
void reset () {
  printf("\033[0m");
}

/* initialize() */
void initialize(){
	time(&big_bang);

	// Initialization of mutexes to 1 such that only one thread at time has to access the critical section

    sem_init(&mutex, 0, 1);
    sem_init(&mutex1, 0, 1);
	sem_init(&mutex2, 0, 1);
	sem_init(&mutex3, 0, 1);
	sem_init(&mutex4, 0, 1);

	// Initialization of semaphores to 0 since each thread has to wait for other threads and for the
	// resource to be available.

	sem_init(&ready, 0, 0);
	sem_init(&wait, 0, 0);
	sem_init(&toast, 0, 0);
	sem_init(&drink, 0, 0);
	sem_init(&mingle, 0, 0);

}

void do_action(char *thread_name, char *action_name, int max_delay) {
	// you can use thread_name and action_name if you wish to display some output
	int delay=rand()%max_delay+1;

	printf("[%4.0f]\t%s %s\n", difftime(time(NULL),big_bang),(char*) thread_name,(char*) action_name);

	sleep(delay);
}

void *buddy(void *thread_name) {

	int id=((char *)thread_name)[0]-'A';

	printf("%s joined the party\n", (char*) thread_name);

	FOREVER {

		do_action(thread_name, "go refill glass", REFILL_TIME);

		wait_for_ready();

		if(!time_up){
			green();
			printf("[%4.0f]\t%s: Is ready for toast!\n", difftime(time(NULL),big_bang), (char*) thread_name);
			reset();
		}

		wait_for_toasting();

		if(!time_up){
			cyan();
			printf("[%4.0f]\t%s: Skol!\n", difftime(time(NULL),big_bang), (char*) thread_name);
			reset();
		}

		make_toast();

		red();
		printf("[%4.0f]\t%s: Is making the toast!\n", difftime(time(NULL),big_bang), (char*) thread_name);
		reset();

		wait_for_drinking();

		if(!time_up) {

			blue();
			printf("[%4.0f]\t%s: Drinks!\n", difftime(time(NULL),big_bang), (char*) thread_name);
			reset();

			drunk_glasses[id]++;

			/* wait_for_mingle(); If we use this function we allow the buddies to wait for all 5 to mix
			 	 	 	 	 	 	before going to find another group.*/

			yellow();
			do_action(thread_name, "mingles", MINGLE_TIME);
			reset();
		}

	}

	printf("%s left the party\n", (char*) thread_name);
	pthread_exit(NULL);
}


int main(void) {

	int high_numb_glasses = 0;
	int low_numb_glasses=0;
	int high_index = 0;
	int low_index = 0;

	pthread_t tid[N_THREADS];
	name_t thread_name[N_THREADS] = {"Ali","Burhan","Cristina","Daniele",
	"Enrica","Filippo","Girish","Heidi","Ivan","Jereney","Kathy","Luca",
	"Mehran", "Nick", "Orazio", "Prem", "Quentin", "Reza", "Saad"};

	initialize();

	puts("\nWELCOME BUDDIES\n");

	for(int i=0;i<N_THREADS;i++) {
		pthread_create(&tid[i],NULL,buddy,thread_name[i]);

	}

	sleep(END_OF_TIME);

	time_up=TRUE;

	printf("\nEND OF TIME\n");

	// UNLOCK WAITING THREADS

	if (time_up) {
	   for (int i = 0; i < N_THREADS; i++) {
	         sem_post(&mutex);
	         sem_post(&mutex1);
	         sem_post(&mutex2);
	         sem_post(&mutex3);

	         sem_post(&ready);
	         sem_post(&wait);
	         sem_post(&drink);
	         sem_post(&toast);
	        }
	}

	for(int i=0;i<N_THREADS;i++) {
		int id=((char *)thread_name[i])[0] -'A';
		pthread_join(tid[i],NULL);
		// UPDATE STATISTICS?

		blue();
		printf("\n%s has drunk %d glasses\n",thread_name[i],drunk_glasses[id]);
		reset();

		// now we want to define who drunk the most and who drunk the least

		if(drunk_glasses[id] > high_numb_glasses){

			high_numb_glasses = drunk_glasses[id];
			high_index = id;
		}

		if(drunk_glasses[id] < low_numb_glasses || low_numb_glasses == 0){

			low_numb_glasses = drunk_glasses[id];
			low_index = id;
		}

	}

	sem_destroy(&mutex);
	sem_destroy(&mutex1);
	sem_destroy(&mutex2);
	sem_destroy(&mutex3);

	sem_destroy(&ready);
	sem_destroy(&wait);
	sem_destroy(&toast);
	sem_destroy(&drink);
	sem_destroy(&mingle);

	pink();
	printf("\nParty statistics.\n- The most sober participant was %s, had only %d glasses :(\n- The thirstiest was %s. That party animal drunk as many as %d glasses B)\n",
			thread_name[low_index], low_numb_glasses,
			thread_name[high_index], high_numb_glasses);
	reset();

	puts("\nGOODNIGHT BUDDIES\n");
	return EXIT_SUCCESS;
}